Config = {}

Config.GarageLocation = vector4(1138.69, -1585.63, 35.38, 176.88)
Config.SpawnLocation = vector4(1136.86, -1591.17, 35.31, 179.23)

-- true = usar ox_target
-- false = usar qb-target
Config.UseOxTarget = true

-- Turbo global / zona (si quieres exigir estar en banco/puesto para activar)
Config.Turbo = {
    requireZone = true,
    coords = vector3(1138.78, -1618.02, 34.72), -- por defecto el que usabas
    maxDistance = 3.0
}

-- 🔹 Definición de divisiones con colores y vehículos
Config.Divisions = {
    EMS = {
        label = "EMS",
        vehicles = {
            --{ model = 'Ambulance',            name = 'Ambulance',           brand = 'Brute',    rank = 2 },
            { model = 'emsnspeedo',                      name = 'Speeddo',             brand = 'Vapid',    rank = 2 },
            { model = 'emsroamer',                       name = 'Camioneta',           brand = 'Declasse', rank = 2 },
            { model = 'ttmodz_izzy_buffalo4',            name = 'Buffalo',             brand = 'Bravado',  rank = 2 },
            { model = 'ttmodz_izzy_castigator',          name = 'Castigator',          brand = 'Canis',    rank = 2 },
            { model = 'ttmodz_izzy_dorado',              name = 'Dorado',              brand = 'Vapid',    rank = 2 },
            { model = 'ambulance',                       name = 'Ambulancia',          brand = 'Brute',    rank = 2 },
            { model = 'ambulance2',                      name = 'Ambulancia Grande',   brand = 'Vapid',    rank = 2 },
            { model = '2vd_vscout2',                     name = 'Scout Medical',       brand = 'Vapid',    rank = 2 },
            { model = '2vd_vsandking',                   name = 'Scout Medical Caja',  brand = 'Vapid',    rank = 2 },
        }
    },
}

-- Configs específicas de vehículos (aquí defines mods, extras, ruedas, color y turbo por coche)
Config.VehicleMods = {
    ["ttmodz_izzy_buffalo4"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["emsnspeedo"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["emsroamer"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["ttmodz_izzy_castigator"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["ttmodz_izzy_dorado"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["STEEDAMB"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 2,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["ambulance"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 1,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["ambulance2"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 1,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["2vd_vscout2"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    ["2vd_vsandking"] = {
        color = {131, 131},
        rimColor = 131,
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=0,[4]=4,[5]=-1,[6]=9,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[35]=0,[42]=0,[43]=4,[44]=3,[45]=3,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },

    -- si quieres puedes añadir más coches aquí siguiendo el patrón:
    -- ["modelo"] = { color = {primary,secondary}, livery = X, wheels = {...}, mods = {...}, extras = {...}, turbo = { enabled = true, multiplier = 1.95, applyOnSpawn = true, manual = true } }
}

-- ==========================================================
-- 🔹 SISTEMA DE HELICÓPTEROS POLICIALES
-- ==========================================================
Config.PoliceHelicopterSystem = {
    enabled = true,
    vehicleModel = "polmav",
    locations = {
        {
            name = "Hospital General",
            requestCoords = vector3(1145.42, -1598.95, 34.84),
            spawnCoords = vector4(1156.03, -1599.85, 35.08, 128.69),
            storeCoords = vector3(1154.77, -1601.31, 34.7),
            radius = 3.0
        },
        --{
          --  name = "Aeropuerto",
         --   requestCoords = vector3(-964.0, -2992.0, 13.95),
        --    spawnCoords = vector4(-975.0, -2992.0, 13.95, 60.0),
        --    storeCoords = vector3(-970.0, -2992.0, 13.95),
         --   radius = 3.0
        --},
        -- {
        --     name = "Comisaría Norte", 
        --     requestCoords = vector3(-464.78, 5992.47, 30.27),
        --     spawnCoords = vector4(-475.15, 5988.57, 31.72, 310.32),
        --     storeCoords = vector3(-474.29, 5989.85, 31.34),
        --     radius = 3.0
        -- },
        -- 🔹 Agrega más ubicaciones aquí:
        -- {
        --     name = "Nombre de la ubicación",
        --     requestCoords = vector3(x, y, z),
        --     spawnCoords = vector4(x, y, z, heading),
        --     storeCoords = vector3(x, y, z),
        --     radius = 3.0
        -- }
    },
    
    -- 🔹 CONFIGURACIÓN DEL VEHÍCULO
    vehicleConfig = {
        ["polmav"] = {
            color = {131, 40}, -- negro mate
            livery = 1,     -- skin policial aérea
            wheels = nil,   -- no aplica en helicópteros
            mods = { 
                [48] = 1, -- elegir livery policial
                [23] = -1,
                [21] = -1
            },
            extras = {
                [1] = true,  -- spotlight activado
                [2] = true, -- sin flotadores
                [7] = true,
                [10] = true,
                [11] = true
            },
            turbo = { enabled = false, multiplier = 1.0, applyOnSpawn = false, manual = false }
        }
    }
}