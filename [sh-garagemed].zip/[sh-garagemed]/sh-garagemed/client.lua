-- CLIENT SIDE - GARAGE medicoL CON NUI + qb-target

local QBCore  = exports['qb-core']:GetCoreObject()
local menuOpen = false

-- ► Configuración embebida (usa el mismo config que antes; aquí asumo que el Config está definido abajo tal como en tu archivo)
-- (He mantenido la gran tabla Config que ya tenías; en tu archivo real deja la misma Config que te pasé/tenías.)
-- Para referencia usé la versión que me enviaste (base): :contentReference[oaicite:2]{index=2}

-- (AQUÍ VA TU BLOQUE Config = { ... } completo; en este cliente lo tienes ya definido arriba en tu archivo original.
--  Si mantienes el mismo cliente que me diste, no hace falta duplicarlo aquí.)

-- Table para controlar turbos activos y valores originales
local boostedVehicles = {}        -- boostedVehicles[plate] = { multiplier = X, topSpeedAdd = Y }
local originalHandling = {}       -- originalHandling[plate] = original fInitialDriveForce
local topSpeedAdded = {}          -- topSpeedAdded[plate] = amount added to top speed (para revertir)

-- ► Crear el ped y target (igual que antes)
CreateThread(function()
    local model = `s_m_m_doctor_01`
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(10)
    end

    local ped = CreatePed(4, model,
        Config.GarageLocation.x,
        Config.GarageLocation.y,
        Config.GarageLocation.z - 1.0,
        Config.GarageLocation.w,
        false, true
    )

    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    loadAnimDict("amb@world_human_cop_idles@male@idle_b")
    TaskPlayAnim(ped, "amb@world_human_cop_idles@male@idle_b", "idle_e",
        8.0, -8, -1, 1, 0, false, false, false)

    ---------------------------------------------------
    -- OX TARGET (QBOX-COMPATIBLE)
    ---------------------------------------------------
-- Reemplaza el bloque de ox_target en sh-garagem por esto:
if Config.UseOxTarget then
    -- Usamos addLocalEntity (igual que en sh-garagepol) para asegurar que
    -- el target se registre correctamente en el cliente.
    exports.ox_target:addLocalEntity(ped, {
        {
            name = 'sh_garagemed_open',
            icon = "fa-solid fa-car",
            label = "Abrir Garage Médico",
            distance = 3.0,
            -- canInteract asegura que solo lo vean jugadores con job 'ambulance'
            canInteract = function(_, distance)
                if distance and distance > 3.0 then return false end
                local pd = QBCore.Functions.GetPlayerData()
                return pd and pd.job and pd.job.name == 'ambulance' and pd.job.onduty
            end,
            onSelect = function()
                if menuOpen then return end
                menuOpen = true
                SetNuiFocus(true, true)
                SendNUIMessage({ action = 'openGarageMenu', data = Config.Divisions })
            end,
            groups = { ambulance = 0 } -- redundante con canInteract, pero seguro
        },
        {
            name = 'sh_garagemed_store',
            icon = "fa-solid fa-warehouse",
            label = "Guardar Vehículo",
            distance = 3.0,
            canInteract = function(_, distance)
                if distance and distance > 3.0 then return false end
                local pd = QBCore.Functions.GetPlayerData()
                return pd and pd.job and pd.job.name == 'ambulance' and pd.job.onduty
            end,
            onSelect = function()
                SaveToNearestGarage()
            end,
            groups = { ambulance = 0 }
        }
    })
else
    -- qb-target fallback (sin cambios)
    exports['qb-target']:AddTargetEntity(ped, {
        options = {
            {
                icon    = "fas fa-car",
                label   = "Abrir Garage Médico",
                action  = function()
                    if menuOpen then return end
                    menuOpen = true
                    SetNuiFocus(true, true)
                    SendNUIMessage({
                        action = 'openGarageMenu',
                        data = Config.Divisions
                    })
                end,
                job     = "ambulance",
            },
            {
                icon    = "fas fa-warehouse",
                label = "Guardar Vehículo",
                action  = SaveToNearestGarage,
                job     = "ambulance",
            }
        },
        distance = 3.0
    })
end

end)

-- ► NUI callbacks
RegisterNUICallback('closeMenu', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

-- Spawn vehicle callback: aplicamos el tuning global, luego la config específica y ( opcional ) el turbo si está configurado para applyOnSpawn
RegisterNUICallback('spawnVehicle', function(data, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    QBCore.Functions.SpawnVehicle(data.model, function(veh)
        local plate = "MED" .. tostring(math.random(10000, 99999))
        SetVehicleNumberPlateText(veh, plate)
        SetEntityHeading(veh, Config.SpawnLocation.w)
        SetVehicleEngineOn(veh, true, true, true)
        SetVehicleFuelLevel(veh, 100.0)
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        TriggerEvent("vehiclekeys:client:SetOwner", plate)

        -- Aplicar tuning genérico
        applyFullTuning(veh)

        -- Aplicar configuración específica si existe
        if Config.VehicleMods[data.model] then
            applyVehicleConfig(veh, Config.VehicleMods[data.model])

            -- Aplicar turbo automático si está configurado así
            local cfg = Config.VehicleMods[data.model]
            if cfg.turbo and cfg.turbo.enabled and cfg.turbo.applyOnSpawn then
                local mult = cfg.turbo.multiplier or 1.9
                -- Guardamos original y aplicamos turbo
                local currentForce = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce')
                originalHandling[plate] = originalHandling[plate] or currentForce
                local newForce = currentForce * mult
                SetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce', newForce)
                local topAdd = 20.0 * (mult - 1.0)
                ModifyVehicleTopSpeed(veh, topAdd)
                boostedVehicles[plate] = { multiplier = mult }
                topSpeedAdded[plate] = (topSpeedAdded[plate] or 0) + topAdd
            end
        end

        QBCore.Functions.Notify("Vehículo asignado: " .. plate, "success")
    end, Config.SpawnLocation, true)
    cb({})
end)

RegisterNUICallback('menuStateChange', function(data, cb)
    menuOpen = data.menuOpen
    SetNuiFocus(data.menuOpen, data.menuOpen)
    cb({})
end)

-- ► Función de “guardar” (despawn)
function SaveToNearestGarage()
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 then
        return QBCore.Functions.Notify("No estás en un vehículo.", "error")
    end
    TaskLeaveVehicle(PlayerPedId(), veh, 0)
    Wait(500)
    QBCore.Functions.DeleteVehicle(veh)
    QBCore.Functions.Notify("Vehículo retirado del servicio.", "success")
end

-- ► Helpers
function loadAnimDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
end

-- -----------------------
-- TURBO: funciones auxiliares
-- -----------------------
local function getPlateFromVeh(veh)
    if not DoesEntityExist(veh) then return nil end
    local plate = GetVehicleNumberPlateText(veh) or ""
    return plate
end

local function applyTurboToVehicle(veh, plate, multiplier)
    if not DoesEntityExist(veh) then return false end
    multiplier = multiplier or 1.9
    SetVehicleModKit(veh, 0)
    local currentForce = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce')
    -- store original only once
    if not originalHandling[plate] then
        originalHandling[plate] = currentForce
    end
    local newForce = originalHandling[plate] * multiplier
    SetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce', newForce)
    local topAdd = 20.0 * (multiplier - 1.0) -- valor aproximado para top speed; ajustable
    ModifyVehicleTopSpeed(veh, topAdd)
    boostedVehicles[plate] = { multiplier = multiplier }
    topSpeedAdded[plate] = (topSpeedAdded[plate] or 0) + topAdd
    return true
end

local function removeTurboFromVehicle(veh, plate)
    if not DoesEntityExist(veh) then return false end
    if originalHandling[plate] then
        SetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce', originalHandling[plate])
        originalHandling[plate] = nil
    end
    -- revert top speed added (si lo hicimos)
    if topSpeedAdded[plate] then
        ModifyVehicleTopSpeed(veh, -topSpeedAdded[plate])
        topSpeedAdded[plate] = nil
    end
    boostedVehicles[plate] = nil
    return true
end

-- Comando para alternar turbo (usa la configuración de Config.VehicleMods para permitir/ajustar)
RegisterCommand("turbo", function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        return QBCore.Functions.Notify("Debes estar dentro del vehículo para activarle el turbo.", "error")
    end

    -- Si se requiere zona para activar turbo, comprobarlo
    if Config.Turbo and Config.Turbo.requireZone then
        local pos = GetEntityCoords(ped)
        if #(pos - Config.Turbo.coords) > (Config.Turbo.maxDistance or 3.0) then
            return QBCore.Functions.Notify("No estás en la zona de activación del turbo.", "error")
        end
    end

    local modelHash = GetEntityModel(veh)
    local modelName = nil
    -- buscar el model name en Config.VehicleMods (clave = nombre del modelo)
    for k,_ in pairs(Config.VehicleMods) do
        if GetHashKey(k) == modelHash then
            modelName = k
            break
        end
    end

    if not modelName then
        return QBCore.Functions.Notify("Este vehículo no tiene turbo configurado en el garage.", "error")
    end

    local cfg = Config.VehicleMods[modelName]
    if not cfg or not cfg.turbo or not cfg.turbo.enabled then
        return QBCore.Functions.Notify("Turbo no disponible para este vehículo (config).", "error")
    end

    if cfg.turbo.manual == false then
        return QBCore.Functions.Notify("Turbo en este vehículo está deshabilitado para activación manual.", "error")
    end

    local plate = getPlateFromVeh(veh)
    if boostedVehicles[plate] then
        -- quitar turbo
        removeTurboFromVehicle(veh, plate)
        QBCore.Functions.Notify("Turbo desactivado.", "primary")
    else
        -- aplicar turbo con el multiplicador del config
        local mult = cfg.turbo.multiplier or 1.9
        applyTurboToVehicle(veh, plate, mult)
        local displayName = GetDisplayNameFromVehicleModel(GetEntityModel(veh))
        QBCore.Functions.Notify("🚀 Turbo activado en " .. displayName .. " (x" .. tostring(mult) .. ")", "success")
    end
end)

-- -----------------------
-- TUNING / CONFIG APPLY (ya lo tenías) - no tocar
-- -----------------------
function applyFullTuning(vehicle)
    SetVehicleModKit(vehicle, 0)
    for i = 0, 16 do
        if i ~= 15 then -- no suspensiones
            local count = GetNumVehicleMods(vehicle, i)
            if count > 0 then
                SetVehicleMod(vehicle, i, count - 1, false)
            end
        end
    end
    ToggleVehicleMod(vehicle, 18, true) -- turbo (esto solo define el mod, el handling lo aplica la parte de turbo de arriba)
end

function applyVehicleConfig(vehicle, cfg)
    SetVehicleModKit(vehicle, 0)
    if cfg.color then
        SetVehicleColours(vehicle, cfg.color[1], cfg.color[2])
    end
    if cfg.rimColor then
    local pearl, wheelColor = GetVehicleExtraColours(vehicle)
    SetVehicleExtraColours(vehicle, pearl, cfg.rimColor)
end
    if cfg.livery then
        SetVehicleLivery(vehicle, cfg.livery)
    end
    if cfg.wheels then
        SetVehicleWheelType(vehicle, cfg.wheels.type)
        SetVehicleMod(vehicle, 23, cfg.wheels.index, false)
    end
    if cfg.mods then
        for modType, modIndex in pairs(cfg.mods) do
            SetVehicleMod(vehicle, modType, modIndex, false)
        end
    end
    if cfg.extras then
        for extraId, state in pairs(cfg.extras) do
            SetVehicleExtra(vehicle, extraId, state and 0 or 1)
        end
    end
end

----------------------------------------------------------------
---------------------------------------------------------------
---------------------------------------------------------------

-- Salir si el sistema está desactivado
if not Config.PoliceHelicopterSystem.enabled then
    return
end

local locations = Config.PoliceHelicopterSystem.locations
local vehicleConfig = Config.PoliceHelicopterSystem.vehicleConfig
local vehicleModel = Config.PoliceHelicopterSystem.vehicleModel

-- NUEVO DRAW-TEXT PERSONALIZADO
function Texto3D(x, y, z, texto)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)

        -- COLOR AMARILLO
        SetTextColour(255, 215, 0, 255)

        -- EFECTOS
        SetTextOutline()
        SetTextDropShadow(2, 0, 0, 0, 200)

        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(texto)
        DrawText(_x, _y)
    end
end


-- Draw markers + interaction para múltiples ubicaciones
CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local pedCoords = GetEntityCoords(ped)

        for _, location in ipairs(locations) do

            --------------------------------------------------------------------
            -- 🔹 MARKER PARA PEDIR HELICÓPTERO
            --------------------------------------------------------------------
            if #(pedCoords - location.requestCoords) < location.radius then
                sleep = 0

                DrawMarker(2, location.requestCoords.x, location.requestCoords.y, location.requestCoords.z - 0.55, 
                    0, 0, 0, 0, 0, 180,
                    0.5, 0.5, 0.5,
                    0, 0, 0, 200,
                    false, false, 2, false)

                -- REEMPLAZAMOS DrawText3D DE QBCORE POR TU NUEVO Texto3D
                Texto3D(
                    location.requestCoords.x,
                    location.requestCoords.y,
                    location.requestCoords.z,
                    "[E] Pedir Helicóptero - " .. location.name
                )

                if IsControlJustReleased(0, 38) then
                    QBCore.Functions.SpawnVehicle(vehicleModel, function(veh)
                        local plate = "AIR" .. tostring(math.random(1000, 9999))
                        SetVehicleNumberPlateText(veh, plate)
                        SetEntityHeading(veh, location.spawnCoords.w)
                        SetVehicleEngineOn(veh, true, true, true)
                        TaskWarpPedIntoVehicle(ped, veh, -1)
                        TriggerEvent("vehiclekeys:client:SetOwner", plate)
                        QBCore.Functions.Notify("Helicóptero Mèdico desplegado en " .. location.name, "success")

                        -- Aplicar config existente
                        if vehicleConfig[vehicleModel] then
                            applyVehicleConfig(veh, vehicleConfig[vehicleModel])
                        end
                    end, location.spawnCoords, true)
                end
            end


            -- 🔹 MARKER PARA GUARDAR HELICÓPTERO
            if #(pedCoords - location.storeCoords) < location.radius then
                local veh = GetVehiclePedIsIn(ped, false)

                if veh ~= 0 and GetVehicleClass(veh) == 15 then
                    sleep = 0

                    DrawMarker(2, location.storeCoords.x, location.storeCoords.y, location.storeCoords.z - 0.55,
                        0, 0, 0, 0, 0, 0,
                        0.5, 0.5, 0.5,
                        255, 0, 0, 150,
                        false, false, 2, false)

                    -- REEMPLAZO DEL TEXTO
                    Texto3D(
                        location.storeCoords.x,
                        location.storeCoords.y,
                        location.storeCoords.z,
                        "[E] Guardar Helicóptero - " .. location.name
                    )

                    if IsControlJustReleased(0, 38) then
                        QBCore.Functions.DeleteVehicle(veh)
                        QBCore.Functions.Notify("🚁 Helicóptero guardado en " .. location.name, "success")
                    end
                end
            end

        end -- for each location

        Wait(sleep)
    end
end)