let divisions = null;
let history = []; // pista de navegación
const menuEl    = document.getElementById('menu');
const contentEl = document.getElementById('content');
const closeBtn  = document.getElementById('close');
const backBtn   = document.getElementById('back');

window.addEventListener('message', (e) => {
  if (e.data.action === 'openGarageMenu') {
    divisions = e.data.data;
    history = [];
    renderDivisions();
    menuEl.classList.remove('hidden');
  }
});

// Cerrar menú
closeBtn.onclick = () => {
  menuEl.classList.add('hidden');
  fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST', headers:{'Content-Type':'application/json'}, body: "{}" });
};

// Volver atrás
backBtn.onclick = () => {
  if (history.length > 0) {
    history.pop();
    if (history.length === 0) {
      renderDivisions();
    } else {
      renderVehicles(history[history.length-1]);
    }
  }
  if (history.length === 0) backBtn.classList.add('hidden');
};

// Mostrar divisiones
function renderDivisions() {
  closeBtn.disabled = false;
  backBtn.classList.add('hidden');
  contentEl.innerHTML = '';
  for (const key in divisions) {
    const div = divisions[key];
    let btn = document.createElement('div');
    btn.className = 'item';
    btn.textContent = div.label;
    btn.onclick = () => {
      history.push(key);
      renderVehicles(key);
      backBtn.classList.remove('hidden');
    };
    contentEl.append(btn);
  }
}

function renderVehicles(divKey) {
  const list = divisions[divKey].vehicles;
  contentEl.innerHTML = '';

  list.forEach(v => {
    const btn = document.createElement('div');
    btn.className = 'item';

    // Solo nombre del vehículo (sin imagen)
    btn.innerHTML = `
      <div class="vehicle-name">${v.name}</div>
    `;

    btn.onclick = () => {
      fetch(`https://${GetParentResourceName()}/spawnVehicle`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ model: v.model })
      });
      menuEl.classList.add('hidden');
    };

    contentEl.append(btn);
  });
}

// Bloquear click cuando está abierto: en vez de SetNuiFocus, avisamos al cliente
let menuOpen = false;
new MutationObserver(() => {
  menuOpen = !menuEl.classList.contains('hidden');
  // Avisamos al cliente para que maneje SetNuiFocus
  fetch(`https://${GetParentResourceName()}/menuStateChange`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json; charset=UTF-8'},
    body: JSON.stringify({ menuOpen })
  });
}).observe(menuEl, { attributes: true, attributeFilter: ['class'] });
