local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent("sh-garagemed:registrarVehiculoServer", function(plate, model)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    -- 🔒 Verificamos que sea policía
    if Player.PlayerData.job.name ~= "ambulance" or Player.PlayerData.job.type ~= "ems" then
        print(('[sh-garagemed] %s intentó registrar vehículo pero no es policía leo'):format(Player.PlayerData.name))
        return
    end
end)
